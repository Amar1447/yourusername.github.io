import { Sparkles } from 'lucide-react';

export function CTA() {
  return (
    <section className="bg-blue-600 text-white py-20">
      <div className="container mx-auto px-6 text-center">
        <div className="max-w-3xl mx-auto">
          <Sparkles className="h-12 w-12 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Audio?</h2>
          <p className="text-xl mb-8">Start with 30 minutes of free transcription. No credit card required.</p>
          <button className="bg-white text-blue-600 px-8 py-4 rounded-full hover:bg-gray-100 transition-colors">
            Start Free Trial
          </button>
        </div>
      </div>
    </section>
  );
}