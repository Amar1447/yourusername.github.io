import { Wand2, Clock, Lock } from 'lucide-react';
import { FeatureCard } from '../ui/FeatureCard';

export function Features() {
  const features = [
    {
      icon: <Wand2 className="h-8 w-8 text-blue-600" />,
      title: "AI-Powered Accuracy",
      description: "Advanced machine learning ensures precise transcriptions across multiple accents and languages."
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: "Lightning Fast",
      description: "Get your transcriptions in minutes, not hours. Real-time processing for quick results."
    },
    {
      icon: <Lock className="h-8 w-8 text-blue-600" />,
      title: "Secure & Private",
      description: "Bank-level encryption keeps your audio files and transcriptions completely secure."
    }
  ];

  return (
    <section className="bg-gray-50 py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-16">Why Choose AudioScribe?</h2>
        <div className="grid md:grid-cols-3 gap-12">
          {features.map((feature) => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </div>
    </section>
  );
}