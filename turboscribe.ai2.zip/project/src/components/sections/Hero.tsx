import { ChevronRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="container mx-auto px-6 py-20 text-center">
      <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
        Transform Your Audio Into
        <span className="text-blue-600"> Perfect Text</span>
      </h1>
      <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
        Advanced AI-powered transcription that delivers accurate results in minutes. Perfect for podcasters, journalists, and professionals.
      </p>
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <button className="bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition-colors flex items-center justify-center">
          Start Transcribing Free <ChevronRight className="ml-2 h-5 w-5" />
        </button>
        <button className="border-2 border-gray-200 text-gray-700 px-8 py-4 rounded-full hover:border-blue-600 hover:text-blue-600 transition-colors">
          View Demo
        </button>
      </div>
    </section>
  );
}