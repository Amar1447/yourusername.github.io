import { Step } from '../ui/Step';

export function HowItWorks() {
  const steps = [
    {
      number: 1,
      title: "Upload Your Audio",
      description: "Drag and drop your audio or video file in any format"
    },
    {
      number: 2,
      title: "AI Processing",
      description: "Our advanced AI transcribes your content with high accuracy"
    },
    {
      number: 3,
      title: "Get Results",
      description: "Download your polished transcript in multiple formats"
    }
  ];

  return (
    <section className="container mx-auto px-6 py-20">
      <h2 className="text-3xl font-bold text-center mb-16">How It Works</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {steps.map((step) => (
          <Step key={step.number} {...step} />
        ))}
      </div>
    </section>
  );
}